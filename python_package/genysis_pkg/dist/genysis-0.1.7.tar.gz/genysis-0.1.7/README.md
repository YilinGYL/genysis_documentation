# GENYSIS

GENYSIS is an API designed to help developers leverage generative design techniques for 3D applications.
